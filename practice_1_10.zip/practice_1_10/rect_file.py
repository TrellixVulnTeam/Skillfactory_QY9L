from rect_class import Rectangle

a = Rectangle(5, 10, 50, 100)
print(a.get_coords())
print(a.get_area())
